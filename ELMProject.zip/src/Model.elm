module Model exposing (..)

import Html exposing (b, div, p, text)
import Model.Date as Date
import Model.Event as Event exposing (Event)
import Model.Event.Category exposing (..)
import Model.Interval as Interval
import Model.PersonalDetails exposing (DetailWithName, PersonalDetails)
import Model.Repo exposing (Repo, view)


type alias Model =
    { personalDetails : PersonalDetails
    , events : List Event
    , selectedEventCategories : SelectedEventCategories
    , repos : List Repo
    }


academicEvents : List Event
academicEvents =
    [ { title = "High School Graduation"
      , interval = Interval.withDurationYears (Date.onlyYear 2015) 4
      , description = p [] [ text "I obtained my High School diploma in 2019, from Colegiul National Emil Racovita ", b [] [ text "My BAC grades were" ], text " good grades." ]
      , category = Academic
      , url = Nothing
      , tags = []
      , important = True
      }
    , { title = "Getting into university"
      , interval = Interval.withDurationYears (Date.onlyYear 2019) 4
      , description = div [] [ text "I entered UTCN , in the department I wanted"]
      , category = Academic
      , url = Nothing
      , tags = []
      , important = False
      }
    ]


workEvents : List Event
workEvents =
    [ 
    ]


projectEvens : List Event
projectEvens =
    [ { title = "Hotel simulator"
      , interval = Interval.oneYear 2020
      , description = text "Small app in Java describing and simulating the functionality of a hotel management application. The users could log in and based on their role, they would be redirected to different pages from where they could perfom specific actions (Managers could see details about rooms, while customers could only create and delete bookings"
      , category = Project
      , url = Nothing
      , tags = []
      , important = True
      }
    , { title = "Polinomial calculator"
      , interval = Interval.oneYear 2020
      , description = text "Small app in java that computed mathematical operations on polynomials ( + , - , * , / )"
      , category = Project
      , url = Nothing
      , tags = []
      , important = False
      }
  
    ]


personalDetails : PersonalDetails
personalDetails =
    { name = "Rus Iulia-Maria"
    , intro = "Hello! I am a year 3 student at the Technical University of Cluj-Napoca, the Computer Science Department."
    , contacts = [ DetailWithName "email" "diess24@icloud.com", DetailWithName "phone Number" "555-21-33-90" ]
    , socials = [ DetailWithName "gitlab" "https://gitlab.com/diess24", DetailWithName "linkedIn" "https://www.linkedin.com/in/iulia-maria-rus-4b39291b9/"]
    }


initModel : Model
initModel =
    { personalDetails = personalDetails
    , events = Event.sortByInterval <| academicEvents ++ workEvents ++ projectEvens
    , selectedEventCategories = allSelected
    , repos =  []
    }
