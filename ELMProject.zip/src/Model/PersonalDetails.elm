module Model.PersonalDetails exposing (..)

import Html exposing (..)
import Html.Attributes exposing (..)


type alias DetailWithName =
    { name : String
    , detail : String
    }

type alias PersonalDetails =
    { name : String
    , contacts : List DetailWithName
    , intro : String
    , socials : List DetailWithName
    }

view : PersonalDetails -> Html msg
view details =
    div [] 
    [
        h1 [id "name"] 
            [
                text <| "Name:" ++ (.name details)
            ]
        ,
        em [id "intro"]
        [
            text <| "Short introduction: " ++ (.intro details) 
        ]
        , h3 [] [ i [] [ text "Contact Details:" ]]
        , ul [] <| List.map (\con -> li [ class "contact-detail"] [ text <| (.name con ++ " " ++ .detail con) ]) (.contacts details)
        ,   
        ul []
        <| List.map (\nameSocial -> li [] [ 
                a 
                    [class ("social-link"), href <| "" ++ (.detail nameSocial) ++ ""] 
                    [text (.name nameSocial)]
                        ]) 
                (.socials details)
        
    ]
