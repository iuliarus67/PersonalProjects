module Model.Event exposing (..)

import Html exposing (..)
import Html.Attributes exposing (class, classList)
import Model.Event.Category exposing (EventCategory(..))
import Model.Interval as Interval exposing (Interval, compare)


type alias Event =
    { title : String
    , interval : Interval
    , description : Html Never
    , category : EventCategory
    , url : Maybe String
    , tags : List String
    , important : Bool
    }


categoryView : EventCategory -> Html Never
categoryView category =
    case category of
        Academic ->
            text "Academic"

        Work ->
            text "Work"

        Project ->
            text "Project"

        Award ->
            text "Award"


sortByInterval : List Event -> List Event
sortByInterval events =
     List.sortWith sortEventByInterval events

sortEventByInterval :  Event -> Event -> Order
sortEventByInterval e1 e2 = 
    case (Interval.compare (.interval e1) (.interval e2)) of
         EQ -> EQ
         LT -> LT
         GT -> GT

turnCategoryToString : EventCategory -> String
turnCategoryToString category = 
        case category of
        Academic -> "Academic"
        Work -> "Work"
        Project -> "Project"
        Award -> "Award"

isImportant : Bool -> String
isImportant isImp = 
    if isImp then " event-important" else ""

certainly : Maybe String -> String
certainly couldBe = 
    case couldBe of
    Nothing -> ""
    Just is -> is

view : Event -> Html Never
view event =
     div [class ("event" ++ isImportant (.important event))] 
    [
        p [class "event-title"] [text <| "Event title: " ++ .title event]
        ,
        p [] [text <| "Description of event : "]
        ,
        p [class "event-description"] [.description event]
        ,
        p [class "event-interval"] [Interval.view event.interval]
        ,
        p [class "event-category"] [ text <| (turnCategoryToString (.category event) )]
        ,
        p [class "event-url"] [text <| certainly(.url event) ]

    ]